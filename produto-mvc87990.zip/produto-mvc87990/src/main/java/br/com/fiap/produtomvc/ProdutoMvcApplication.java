package br.com.fiap.produtomvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdutoMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdutoMvcApplication.class, args);
	}

}
