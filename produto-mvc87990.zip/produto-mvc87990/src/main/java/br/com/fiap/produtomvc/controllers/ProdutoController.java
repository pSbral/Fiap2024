package br.com.fiap.produtomvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

//URL - localhost:8080

@Controller //Essa classe é um Controller (Spring)
@RequestMapping("/produtos") //URL - localhost:8080/produtos

public class ProdutoController {

    //Metódo que ocorre em RUNTIME que atua como o (method=GET)
    @GetMapping
    public String adicionarProduto() {
        return "produto/novo-produto";
    }

    //Metódo que ocorre em RUNTIME que atua como o (method=POST).
    //Redireciona a página após envio do formulário.
    @PostMapping
    public String inserirProduto() {
        return "redirect:/produtos";
    }
}